
#include "optimize.h"

void initAssembly();
void MIPS(const char* filename);